
public class TestServer {

	public static void main(String[] args) {
		System.out.println("Hello");
	}
	
}
